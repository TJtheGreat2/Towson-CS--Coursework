import java.util.Scanner;

public class Calculus {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter x coordinate: ");
        double x = input.nextDouble();
        System.out.print("Enter exponent (y): ");
        double y = input.nextDouble();

        System.out.println("Evaluating tangent for point: (" + x + ", " + y + ")");

        Function f = new Function() {
            public double apply(double val) {
                return Math.pow(val, y);
            }
        };

        double x0 = x; // FIXED: Evaluate at x, not y

        // Calculate the slope of the tangent line
        double slope = derivative(f, x0);

        // Calculate the y-intercept of the tangent line
        double y0 = f.apply(x0);
        double intercept = y0 - slope * x0;

        // Print the equation of the tangent line
        System.out.println("The equation of the tangent line is: y = " + slope + "x + " + intercept);
    }

    // Approximates the derivative using the finite difference method
    private static double derivative(Function f, double x) {
        double h = 0.00001; // Small step size
        return (f.apply(x + h) - f.apply(x)) / h;
    }

    // Functional interface for a function
    @FunctionalInterface
    interface Function {
        double apply(double val);
    }
}