import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    System.out.println("Calculator ");
    System.out.println("(1) Multiplication");
    System.out.println("(2) Division");
    System.out.println("(3) Addition");
    System.out.println("(4) Subtraction");
    System.out.println("(5) Modulus");
    System.out.println("(6) Exponent");
    System.out.println("(7) Percentage");
    System.out.println("(8) Square Root");
    System.out.println("(9) Cube Root");
    System.out.println("(10) Tangent Line");

    System.out.print("\nEnter the number of the problem type that you want: ");
    int num = input.nextInt();
    System.out.println("You selected: " + num);

    switch (num) {
      case 1:
        System.out.println("Enter two numbers: ");
        double numMult1 = input.nextDouble();
        double numMult2 = input.nextDouble();
        System.out.println("The answer is: " + (numMult1 * numMult2));
        break;
      case 2:
        System.out.println("Pick two numbers: ");
        double divNum1 = input.nextDouble();
        double divNum2 = input.nextDouble();
        if (divNum2 == 0) {
          System.out.println("Error: Cannot divide by zero.");
        } else {
          System.out.println("The answer is: " + (divNum1 / divNum2));
        }
        break;
      case 3:
        System.out.println("Pick two numbers: ");
        double addNum1 = input.nextDouble();
        double addNum2 = input.nextDouble();
        System.out.println("The answer is: " + (addNum1 + addNum2));
        break;
      case 4:
        System.out.println("Pick two numbers: ");
        double subNum1 = input.nextDouble();
        double subNum2 = input.nextDouble();
        System.out.println("The answer is: " + (subNum1 - subNum2));
        break;
      case 5:
        System.out.println("Pick a number: ");
        double modNum1 = input.nextDouble();
        System.out.println("Pick another number: ");
        double modNum2 = input.nextDouble();
        System.out.println("The answer is: " + (modNum1 % modNum2));
        break;
      case 6:
        System.out.println("Pick a base number: ");
        double expNum1 = input.nextDouble();
        System.out.println("Pick an exponent: ");
        double expNum2 = input.nextDouble();
        System.out.println("The answer is: " + Math.pow(expNum1, expNum2));
        break;
      case 7:
        System.out.println("Pick a number: ");
        double perNum1 = input.nextDouble();
        System.out.println("Pick a total to divide by: ");
        double perNum2 = input.nextDouble();
        System.out.println("The answer is: " + ((perNum1 / perNum2) * 100) + "%");
        break;
      case 8:
        System.out.println("Pick a number: ");
        double sqrtNum = input.nextDouble();
        System.out.println("The answer is: " + Math.sqrt(sqrtNum));
        break;
      case 9:
        System.out.println("Pick a number: ");
        double cubeNum = input.nextDouble();
        System.out.println("The answer is: " + Math.cbrt(cubeNum));
        break;
      case 10:
        Calculus.main(args);
        break;
      default:
        System.out.println("Invalid selection. Please run the program again.");
        break;
    }

    input.close();
  }
}